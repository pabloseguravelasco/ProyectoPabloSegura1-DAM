package com.salesianostriana.dam.proyecto.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity

/**
 * 
 * @author pablo
 * 
 *         Clase en la cual establecemos sus atributos( entre ellos un objeto
 *         Aficion) y generamos sus constructores, tanto con su id como sin el
 *
 */
public class Usuario {

	@Id
	@GeneratedValue
	private long id;

	private String nombre;
	private String apellidos;
	private String email;
	private int edad;
	private String provincia;
	private LocalDate fechaIngreso;
	private String genero;
	private String comentario;
	private String contrasena;
	private String fotoPerfil;

	public Usuario(String nombre, String apellidos, String email, int edad, String provincia, LocalDate fechaIngreso,
			String genero, String comentario, String contrasena, String fotoPerfil, Aficion aficion) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.email = email;
		this.edad = edad;
		this.provincia = provincia;
		this.fechaIngreso = fechaIngreso;
		this.genero = genero;
		this.comentario = comentario;
		this.contrasena = contrasena;
		this.fotoPerfil = fotoPerfil;
		this.aficion = aficion;
	}

	public Usuario(String nombre, String apellidos, String email, int edad, String provincia, LocalDate fechaIngreso,
			String genero, String comentario, String contrasena, String fotoPerfil) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.email = email;
		this.edad = edad;
		this.provincia = provincia;
		this.fechaIngreso = fechaIngreso;
		this.genero = genero;
		this.comentario = comentario;
		this.contrasena = contrasena;
		this.fotoPerfil = fotoPerfil;
	}

	@ManyToOne
	private Aficion aficion;

}
