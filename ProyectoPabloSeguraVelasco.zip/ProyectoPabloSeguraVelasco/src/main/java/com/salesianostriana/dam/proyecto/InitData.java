package com.salesianostriana.dam.proyecto;

import java.time.LocalDate;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.salesianostriana.dam.proyecto.model.Aficion;
import com.salesianostriana.dam.proyecto.model.Usuario;
import com.salesianostriana.dam.proyecto.servicio.AficionService;
import com.salesianostriana.dam.proyecto.servicio.UsuarioService;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor

/**
 * 
 * @author pablo
 *
 */
public class InitData {

	/**
	 * Esta clase la utilizaremos para obtener insertar datos directamente en la app
	 * como ejemplo de visualización
	 */
	private final UsuarioService servicio;
	private final AficionService aficionService;

	@PostConstruct
	public void init() {

		Aficion aficionBase = new Aficion("Cine");
		Aficion aficionBase1 = new Aficion("Deporte");
		Aficion aficionBase2 = new Aficion("Lectura");
		Aficion aficionBase3 = new Aficion("Videojuegos");

		aficionService.save(aficionBase);
		aficionService.save(aficionBase1);
		aficionService.save(aficionBase2);
		aficionService.save(aficionBase3);

		Usuario a = new Usuario("Ignacio", "Jiménez Olid", "ignajiol@gmail.com", 28, "Valencia", LocalDate.now(),
				"Hombre", "Programador freelance en busca del amor", "1ºdamPASSWORD",
				"https://img.vixdata.io/pd/jpg-large/es/sites/default/files/btg/tech.batanga.com/files/Programador-freelance-Consejos-y-bolsas-de-trabajo-1.jpg",
				aficionService.findById(1L).get());
		Usuario b = new Usuario("Lucía", "Sánchez López", "lusylove@gmail.com", 25, "Mallorca", LocalDate.now(),
				"Mujer", "Soy una chica algo tímida con ganas de conocer gente  nueva", "1ºdamPASSWORD",
				"https://imagenes.20minutos.es/files/image_656_370/uploads/imagenes/2016/10/18/359111.jpg",
				aficionService.findById(1L).get());

		servicio.save(a);
		servicio.save(b);

	}

}