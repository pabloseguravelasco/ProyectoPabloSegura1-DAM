package com.salesianostriana.dam.proyecto.servicio;

import org.springframework.stereotype.Service;


import com.salesianostriana.dam.proyecto.model.Aficion;
import com.salesianostriana.dam.proyecto.repositorio.AficionRepositorio;
import com.salesianostriana.dam.proyecto.servicio.base.BaseService;

@Service
public class AficionService extends BaseService<Aficion, Long, AficionRepositorio> {

}
