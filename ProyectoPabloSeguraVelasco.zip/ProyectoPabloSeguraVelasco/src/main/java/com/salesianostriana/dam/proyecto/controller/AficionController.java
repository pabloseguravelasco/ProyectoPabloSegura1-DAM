package com.salesianostriana.dam.proyecto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.proyecto.model.Aficion;
import com.salesianostriana.dam.proyecto.model.Usuario;
import com.salesianostriana.dam.proyecto.servicio.AficionService;
import com.salesianostriana.dam.proyecto.servicio.UsuarioService;

import java.util.Optional;

@Controller
@RequestMapping("/admin/aficion")
/**
 * 
 * @author pablo Esta clase se utilizará para realizar las diferentes acciones
 *         que va a recibir la clase afición, tanto para editar, crear y borrar
 *
 */
public class AficionController {

	@Autowired
	private UsuarioService usuarioService;
	@Autowired
	private AficionService aficionService;

	/**
	 * 
	 * @param model
	 * @return retorna a la página principal de la aplicación, en nuestro caso al
	 *         index.html
	 * 
	 */
	@GetMapping("/")
	public String mostrarIndex2(Model model) {
		model.addAttribute("usuarios", usuarioService.findAll());

		return "index";
	}

	/**
	 * 
	 * @param model
	 * @return retorna al usuario hacia el listado de aficiones que hay en la app
	 */
	@GetMapping("/list-aficion")
	public String mostrarListaAficiones(Model model) {
		model.addAttribute("aficiones", aficionService.findAll());

		return "admin/list-aficion";
	}

	/**
	 * 
	 * @param model
	 * @return retorna una nueva aficion, que para crearla nos redirecciona al
	 *         formAficion.html
	 */
	@GetMapping("/nuevo")
	public String nuevaAficion(Model model) {
		model.addAttribute("aficion", new Usuario());
		model.addAttribute("usuario", usuarioService.findAll());

		return "admin/formAficion";
	}

	/**
	 * 
	 * @param aficion
	 * @param model
	 * @return una vez se añade la afición, nos retorna a la página principal
	 *         gracias a "redirect:/"
	 */
	@PostMapping("/nuevo/submit")
	public String botonAnyadirAficion(@ModelAttribute("aficion") Aficion aficion, Model model) {

		aficionService.save(aficion);
		return "redirect:/";
	}

	/**
	 * 
	 * @param id
	 * @param model
	 * @return retorna una afición una vez editada, sustituyéndola, y si no
	 *         encuentra afición que editar, no realiza ningún cambio
	 *
	 */

	@GetMapping("edit/{id}")
	public String editarAficion(@PathVariable("id") Long id, Model model) {

		Aficion aficion = aficionService.findById(id).orElse(null);

		if (aficion != null) {
			model.addAttribute("aficion", aficion);

			return "admin/formAficion";

		} else {
			return "redirect:/admin/list-aficion";
		}

	}

	/**
	 * 
	 * @param aficion
	 * @return retornamos al listado para mostrar la lista actualizada con la
	 *         modificación hecha
	 */

	@PostMapping("/edit/submit")
	public String procesarFormularioEdicionAficion(@ModelAttribute("aficion") Aficion aficion) {
		aficionService.edit(aficion);
		return "redirect:/admin/list-aficion";

		// Volvemos a redirigir la listado a través del controller para pintar la lista
		// actualizada con la modificación hecha
	}

	/**
	 * 
	 * @param id
	 * @param model
	 * @return nos retorna a la página principal eliminando la aficion que hemos
	 *         eliminado según si id
	 */

	@GetMapping("borrar/{id}")
	public String borrarAficion(@PathVariable("id") Long id, Model model) {

		aficionService.deleteById(id);
		return "redirect:/";
	}
}
