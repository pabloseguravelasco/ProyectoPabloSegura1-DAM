package com.salesianostriana.dam.proyecto.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.proyecto.model.Usuario;
import com.salesianostriana.dam.proyecto.servicio.AficionService;
import com.salesianostriana.dam.proyecto.servicio.UsuarioService;

@Controller

/* @RequestMapping("/admin/usuario") */

/**
 * 
 * @author pablo Esta clase se utilizará para realizar las diferentes acciones
 *         que va a recibir la clase usuario, tanto para editar, crear y borrar
 * 
 *         Sus métodos son prácticamente iguales a los de la clase
 *         AficionController
 *
 */
public class UsuarioController {

	@Autowired
	private UsuarioService usuarioService;
	@Autowired
	private AficionService aficionService;

	@GetMapping("/")
	public String mostrarIndex(Model model) {
		model.addAttribute("usuarios", usuarioService.findAll());

		return "index";
	}

	@GetMapping("/list-usuarios")
	public String mostrarListaUsuarios(Model model) {
		model.addAttribute("usuarios", usuarioService.findAll());

		return "admin/list-usuarios";
	}

	@GetMapping("/nuevo")
	public String nuevoUsuario(Model model) {
		model.addAttribute("usuario", new Usuario());
		model.addAttribute("aficion", aficionService.findAll());

		return "admin/formUsuario";
	}

	@PostMapping("/nuevo/submit")
	public String botonAnyadirUsuario(@ModelAttribute("usuario") Usuario usuario, Model model) {

		usuarioService.save(usuario);
		return "redirect:/";
	}

	@GetMapping("edit/{id}")
	public String editarUsuario(@PathVariable("id") Long id, Model model) {

		Usuario usuario = usuarioService.findById(id).orElse(null);

		if (usuario != null) {
			model.addAttribute("usuario", usuario);
			model.addAttribute("aficion", aficionService.findAll());
			return "admin/formUsuario";

		} else {
			return "redirect:/admin/usuario/";
		}

	}

	@PostMapping("/edit/submit")
	public String procesarFormularioEdicion(@ModelAttribute("usuario") Usuario usuario) {
		usuarioService.edit(usuario);
		return "redirect:/admin/usuario/list-usuarios";

	}

	@GetMapping("borrar/{id}")
	public String borrarUsuario(@PathVariable("id") Long id, Model model) {

		usuarioService.deleteById(id);
		return "redirect:/";
	}
}
