package com.salesianostriana.dam.proyecto.servicio;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.salesianostriana.dam.proyecto.model.Aficion;
import com.salesianostriana.dam.proyecto.model.Usuario;
import com.salesianostriana.dam.proyecto.repositorio.UsuarioRepositorio;
import com.salesianostriana.dam.proyecto.servicio.base.BaseService;

@Service
public class UsuarioService extends BaseService<Usuario, Long, UsuarioRepositorio> {

}
