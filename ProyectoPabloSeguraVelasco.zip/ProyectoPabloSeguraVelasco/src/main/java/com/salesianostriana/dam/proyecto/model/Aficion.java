package com.salesianostriana.dam.proyecto.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Entity

/**
 * 
 * @author pablo
 * 
 *         Clase Aficion donde establecemos sus atributos y a la cual se le pasa
 *         una lista de usuarios
 *
 */
public class Aficion {

	@Id
	@GeneratedValue
	private long id;

	private String nombre;

	public Aficion(String nombre) {
		this.nombre = nombre;

	}

	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@OneToMany(mappedBy = "aficion", fetch = FetchType.EAGER)
	private List<Usuario> usuarios = new ArrayList<>();

	public void addUsuario(Usuario u) {
		this.usuarios.add(u);
		u.setAficion(this);
	}

	public void removeUsuario(Usuario u) {
		this.usuarios.remove(u);
		u.setAficion(this);
	}

}
