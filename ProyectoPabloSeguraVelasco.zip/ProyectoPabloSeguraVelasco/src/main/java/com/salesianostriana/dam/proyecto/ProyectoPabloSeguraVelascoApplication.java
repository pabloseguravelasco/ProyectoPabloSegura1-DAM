package com.salesianostriana.dam.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
/**
 * 
 * @author pablo Esta clase sirve para ejecutar la aplicación
 */
public class ProyectoPabloSeguraVelascoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoPabloSeguraVelascoApplication.class, args);
	}

}
