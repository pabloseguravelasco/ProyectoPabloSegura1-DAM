package com.salesianostriana.dam.proyecto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.salesianostriana.dam.proyecto.model.Aficion;

public interface AficionRepositorio extends JpaRepository<Aficion, Long> {
}
